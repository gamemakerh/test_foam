# assign inputs
_solution, _field = IN
probes = None

try:
    from butterfly.utilities import loadProbesFromPostProcessingFile
    from butterfly_dynamo.geometry import xyz_to_point
    import butterfly_dynamo.unitconversion as uc
except ImportError as e:
    msg = '\nFailed to import butterfly:'
    raise ImportError('{}\n{}'.format(msg, e))

import os


if _solution and _field:
    if isinstance(_solution, str):
        projectDir = _solution.replace('\\\\','/').replace('\\','/')
        probesDir = os.path.join(projectDir, 'postProcessing\\probes') 
        rawValues = loadProbesFromPostProcessingFile(probesDir, _field)
    else:
        assert hasattr(_solution, 'loadProbes'), \
            'Invalid Input: <{}> is not a valid Butterfly Solution.'.format(_solution)
        try:
            rawValues = _solution.loadProbes(_field)
        except Exception as e:
            raise ValueError('Failed to load probes:\n\t{}'.format(e))
    
    c = 1.0 / uc.convertDocumentUnitsToMeters()
    try:
        probes = tuple(xyz_to_point(v, c) for v in rawValues)
    except:
        probes = rawValues


# assign outputs to OUT
OUT = (probes,)