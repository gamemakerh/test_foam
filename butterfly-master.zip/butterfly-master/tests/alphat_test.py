# coding=utf-8

import unittest
from butterfly.alphat import Alphat


class SunpathTestCase(unittest.TestCase):
    """Test for (ladybug/sunpath.py)"""

    # preparing to test.
    def setUp(self):
        """set up."""
        pass

    def tearDown(self):
        """Nothing to tear down as nothing gets written to file."""
        pass

    def test_default_values(self):
        alph = Alphat()


if __name__ == "__main__":
    unittest.main()
